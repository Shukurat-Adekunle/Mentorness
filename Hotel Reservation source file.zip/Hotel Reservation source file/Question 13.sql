SELECT
	room_type_reserved,
	COUNT(*) AS no_of_reservations,
	AVG(no_of_weekend_nights) ,
    AVG(no_of_week_nights)
FROM
	hotel_reservation.hotel_reservation_dataset
GROUP BY 
	room_type_reserved;