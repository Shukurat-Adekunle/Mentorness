SELECT
	COUNT(Booking_ID) AS no_of_reservations_in_2018
FROM
	hotel_reservation.hotel_reservation_dataset
WHERE
	arrival_date LIKE "%2018";
    