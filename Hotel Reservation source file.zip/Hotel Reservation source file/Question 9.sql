SELECT 
	booking_status,
	COUNT(*) AS confirmed_reservations
FROM 
	hotel_reservation.hotel_reservation_dataset
WHERE booking_status = 'Not_Canceled';
