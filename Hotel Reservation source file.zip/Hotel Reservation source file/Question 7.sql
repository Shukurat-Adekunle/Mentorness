SELECT
	MIN(lead_time) AS lowest_lead_time,
    MAX(lead_time) AS highest_lead_time
FROM
	hotel_reservation.hotel_reservation_dataset;
	