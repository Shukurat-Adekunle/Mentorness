SELECT
	room_type_reserved,
COUNT(*) AS most_common_room_type
FROM	
	hotel_reservation.hotel_reservation_dataset
GROUP BY
	room_type_reserved
ORDER BY  most_common_room_type DESC
LIMIT 1;
