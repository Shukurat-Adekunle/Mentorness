SELECT
	avg(avg_price_per_room) AS avg_orice_per_room_with_children
FROM
	hotel_reservation.hotel_reservation_dataset
WHERE
	no_of_children>0;