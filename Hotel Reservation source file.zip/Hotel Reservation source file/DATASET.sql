SELECT
	*
FROM
	hotel_reservation.hotel_reservation_dataset;