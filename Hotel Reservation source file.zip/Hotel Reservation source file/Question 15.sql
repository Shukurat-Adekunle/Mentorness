SELECT
	market_segment_type,
    COUNT(*) AS no_of_reservations,
    AVG(avg_price_per_room) AS average_price_per_room
FROM
	hotel_reservation.hotel_reservation_dataset
GROUP BY 
	market_segment_type
ORDER BY average_price_per_room DESC
LIMIT 1;