SELECT
	 market_segment_type,
COUNT(*) AS most_common_market_segment_type
FROM	
	hotel_reservation.hotel_reservation_dataset
GROUP BY
	market_segment_type
ORDER BY most_common_market_segment_type DESC
LIMIT 1;

	