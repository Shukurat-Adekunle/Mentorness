SELECT
	room_type_reserved,
COUNT(*) AS most_common_room_type,
AVG(avg_price_per_room)
FROM	
	hotel_reservation.hotel_reservation_dataset
WHERE 
	no_of_children>0
GROUP BY
	room_type_reserved
ORDER BY  most_common_room_type DESC
LIMIT 1;
