SELECT	
type_of_meal_plan,
COUNT(*) AS most_popular_meal_plan
FROM
hotel_reservation.hotel_reservation_dataset
GROUP BY type_of_meal_plan
ORDER BY most_popular_meal_plan DESC
LIMIT 1;
