SELECT
	COUNT(Booking_ID) AS no_of_reservations_on_weekend
FROM
	hotel_reservation.hotel_reservation_dataset
WHERE
	no_of_weekend_nights>0;