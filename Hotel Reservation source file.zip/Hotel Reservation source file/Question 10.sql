SELECT
	SUM(no_of_adults) AS no_of_adults,
    SUM(no_of_children) AS no_of_children,
    SUM(no_of_adults+no_of_children) AS total
FROM
	hotel_reservation.hotel_reservation_dataset;
